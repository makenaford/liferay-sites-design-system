import React, { useEffect } from "react";
import type { Preview, Decorator } from "@storybook/react";

import "../src/styles/tokens.css";
import "../src/styles/base.css";

const withTheme: Decorator = (Story, context) => {
  const theme = context.globals.theme || "dark";

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    document.body.style.background = "var(--bg)";
    document.body.style.color = "var(--text-primary)";
    document.body.style.transition = "background-color .25s, color .25s";
  }, [theme]);

  return (
    <div data-theme={theme} style={{ padding: 24, minHeight: "100vh", background: "var(--bg)" }}>
      <Story />
    </div>
  );
};

const preview: Preview = {
  parameters: {
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i,
      },
    },
    backgrounds: { disable: true },
    layout: "fullscreen",
  },
  globalTypes: {
    theme: {
      name: "Theme",
      description: "Light / dark theme",
      defaultValue: "dark",
      toolbar: {
        icon: "circlehollow",
        items: [
          { value: "light", icon: "sun", title: "Light" },
          { value: "dark", icon: "moon", title: "Dark" },
        ],
        showName: true,
      },
    },
  },
  decorators: [withTheme],
};

export default preview;
